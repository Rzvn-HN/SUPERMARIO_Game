package manager;

public enum ButtonAction {
    JUMP,
    SIT,
    M_RIGHT,
    M_LEFT,
    CROUCH,
    FIRE,
    HAMMER,
    START,
    PAUSE_RESUME,
    ACTION_COMPLETED,
    SELECT,
    YES,
    GO_UP,
    GO_DOWN,
    GO_TO_START_SCREEN,
    NO_ACTION
}
