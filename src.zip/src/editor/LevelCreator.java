package editor;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.io.FileNotFoundException;
import java.io.IOException;

public class LevelCreator {
    public LevelCreator() {
    }

    public static void main(String[] args) throws FileNotFoundException, IOException {
        new Level_11();
    }
}
