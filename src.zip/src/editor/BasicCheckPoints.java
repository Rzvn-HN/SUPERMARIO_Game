package editor;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.awt.Point;

public interface BasicCheckPoints {
    int GetNextLevel();

    Point GetNextLocation();
}
