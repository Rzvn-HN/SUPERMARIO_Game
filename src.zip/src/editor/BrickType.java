package editor;

public enum BrickType {

    BLACK,

    EMPTY,

    GROUND,

    ORDINARY,

    SLIME,

    SUPRISE;


}
