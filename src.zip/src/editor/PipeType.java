package editor;

public enum PipeType {
    GREEN,
    WHITE,

}
