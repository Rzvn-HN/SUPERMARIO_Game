package editor;

public enum EnemyType {
    BIRD,

    CANNIBALLFLOWER,

    KOOPA,

    GOOMBA,

    SPIKEY;



}
