package view;

public enum OnlineOrOfflineMode {
    ONLINE,
    OFFLINE

}
